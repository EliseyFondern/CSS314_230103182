# ==============================================================================
# SECTION 0: LOCAL OPENMP ENVIRONMENT & DETERMINISTIC SEED HARNESS
# ==============================================================================
import os
os.environ["NUMBA_THREADING_LAYER"] = "omp"  # Force native OpenMP runtime (libgomp / iomp)

import time, hashlib, json, math
import numpy as np
import numba as nb
from numba import njit, prange, set_num_threads, get_num_threads, get_thread_id

STUDENT_NAME = "Ramazan Kolganatov"
STUDENT_ID = 230103182

assert isinstance(STUDENT_ID, int) and STUDENT_ID > 0, "Set a valid numeric STUDENT_ID!"
assert (os.cpu_count() or 1) >= 4, "Local multi-core CPU (>=4 logical cores) required; no Colab!"


# Trigger OpenMP layer initialization and verify backend
@njit(parallel=True)
def _omp_probe():
    acc = 0
    for i in prange(64):
        acc += get_thread_id() + 1
    return acc


_ = _omp_probe()
assert nb.threading_layer() == "omp", f"Expected 'omp' layer, got {nb.threading_layer()}"

rng = np.random.default_rng(STUDENT_ID)

# Student-specific OpenMP parameters
N_T1       = 4_000_000 + (STUDENT_ID % 991) * 1024
BINS_T1    = 48 + (STUDENT_ID % 17)
ITERS_T2   = 35_000_000 + (STUDENT_ID % 503) * 10_000
PAD_STRIDE = 8 + (STUDENT_ID % 5) * 8   # >= 8 int64 slots (>= 64 bytes cache-line isolation)
ROWS_T3    = 12_000 + (STUDENT_ID % 257) * 16
SKEW_MOD   = 37 + (STUDENT_ID % 19)
GRID_H     = 384 + (STUDENT_ID % 4) * 32
GRID_W     = 512 + (STUDENT_ID % 5) * 32
OMEGA_SOR  = np.float64(1.72 + (STUDENT_ID % 11) * 0.015)

data_t1    = rng.integers(0, BINS_T1, size=N_T1, dtype=np.int32)
weights_t1 = rng.uniform(0.25, 2.50, size=N_T1).astype(np.float64)

print(f"Backend: {nb.threading_layer()} | Logical Cores: {os.cpu_count()} | Student: {STUDENT_ID}")
print(f"N_T1={N_T1}  BINS_T1={BINS_T1}")


# ==============================================================================
# TASK 1: Race-Condition Forensics & Thread-Private Histogram Reduction
# ==============================================================================
@njit(parallel=True)
def buggy_hist_omp(indices, weights, num_bins):
    hist = np.zeros(num_bins, dtype=np.int64)
    w_sums = np.zeros(num_bins, dtype=np.float64)
    for i in prange(indices.shape[0]):
        b = indices[i]
        hist[b] += 1                  # Data race across OpenMP threads
        w_sums[b] += weights[i]       # Non-associative floating-point race
    return hist, w_sums


# Fixed number of work blocks, independent of the thread count. Each block is
# summed sequentially and blocks are merged in a fixed order 0..SAFE_BLOCKS-1,
# so the floating-point association order never depends on how many threads run.
SAFE_BLOCKS = 64


@njit(parallel=True)
def safe_hist_omp(indices, weights, num_bins):
    max_threads = get_num_threads()
    n = indices.shape[0]
    priv_hist = np.zeros((max_threads, num_bins), dtype=np.int64)   # thread-private rows
    blk_w = np.zeros((SAFE_BLOCKS, num_bins), dtype=np.float64)     # block-private float partials
    worker_hits = np.zeros((max_threads, 8), dtype=np.int64)        # padded: 64 B per worker
    blk_size = (n + SAFE_BLOCKS - 1) // SAFE_BLOCKS

    for blk in prange(SAFE_BLOCKS):
        tid = get_thread_id()
        start = blk * blk_size
        end = min(n, start + blk_size)
        for i in range(start, end):
            b = indices[i]
            priv_hist[tid, b] += 1          # each worker writes only its own row
            blk_w[blk, b] += weights[i]     # each block writes only its own row
        worker_hits[tid, 0] += end - start

    # Deterministic reduction after the parallel region (implicit barrier)
    hist = np.zeros(num_bins, dtype=np.int64)
    w_sums = np.zeros(num_bins, dtype=np.float64)
    for t in range(max_threads):
        for b in range(num_bins):
            hist[b] += priv_hist[t, b]
    for k in range(SAFE_BLOCKS):
        for b in range(num_bins):
            w_sums[b] += blk_w[k, b]
    return hist, w_sums, worker_hits[:, 0].copy()


# --- 1.1 Empirical race demonstration ---
set_num_threads(1)
ref_hist, ref_w = buggy_hist_omp(data_t1, weights_t1, BINS_T1)   # 1 thread -> no race
assert int(ref_hist.sum()) == N_T1, "single-threaded reference must be exact"

set_num_threads(8)
print("\n[Task 1] Race demonstration @ 8 threads (10 runs):")
total_lost = 0
worst_bin_disc = 0
worst_w_disc = 0.0
for run in range(10):
    h, w = buggy_hist_omp(data_t1, weights_t1, BINS_T1)
    lost = N_T1 - int(h.sum())
    max_disc = int(np.abs(h - ref_hist).max())
    max_wdisc = float(np.abs(w - ref_w).max())
    total_lost += lost
    worst_bin_disc = max(worst_bin_disc, max_disc)
    worst_w_disc = max(worst_w_disc, max_wdisc)
    print(f"  run {run}: lost={lost:>8d}  max_bin_disc={max_disc:>7d}  max_w_disc={max_wdisc:.3e}")
print(f"  TOTAL lost over 10 runs = {total_lost}  | worst bin discrepancy = {worst_bin_disc}"
      f"  | worst w_sum discrepancy = {worst_w_disc:.3e}")

# --- 1.2 Deterministic thread-private kernel @ 1/2/4/8 threads ---
print("\n[Task 1] Thread-private safe histogram:")
w_by_threads = {}
safe_hist_omp(data_t1, weights_t1, BINS_T1)   # warm-up: JIT compilation is not timed
for nt in (1, 2, 4, 8):
    set_num_threads(nt)
    t0 = time.perf_counter()
    h, w, hits = safe_hist_omp(data_t1, weights_t1, BINS_T1)
    dt = (time.perf_counter() - t0) * 1e3
    assert np.array_equal(h, ref_hist), f"hist mismatch at {nt} threads"
    active = int(np.count_nonzero(hits))
    assert active == nt, f"only {active}/{nt} workers participated"
    w_by_threads[nt] = w
    print(f"  threads={nt}: total={int(h.sum())}  active_workers={active}  "
          f"time={dt:8.2f} ms  worker_hits={hits.tolist()}")

for nt in (2, 4, 8):
    assert np.array_equal(w_by_threads[nt].view(np.int64), w_by_threads[1].view(np.int64)), \
        f"w_sums not bit-identical at {nt} threads"
print("  hist exact vs reference and w_sums bit-identical across 1/2/4/8 threads: OK")

hist_t1, wsums_t1 = h, w   # used by the final verification digest

# --- 1.3 Digital diagnosis ---
DIAGNOSIS_T1 = (
    "Even if every integer increment were made atomic, the weighted sums would still be "
    "non-deterministic because IEEE-754 floating-point addition is not associative: each "
    "addition rounds the result to a 53-bit mantissa, so (a + b) + c can differ from "
    "a + (b + c) in the last bits. With prange the OS and OpenMP runtime decide which thread "
    "reaches a shared bin first, so the order in which the weights are added changes from run "
    "to run and with the thread count, and the rounding errors accumulate differently each "
    "time. Atomics only prevent lost updates; they do not fix the order of the operations. "
    "My safe kernel therefore splits the data into a fixed number of blocks that does not "
    "depend on the thread count, sums each block sequentially, and merges the partial results "
    "in a fixed order, which makes the output bit-identical at 1, 2, 4 and 8 threads."
)


# ==============================================================================
# TASK 2: Eliminating Cache-Line False Sharing in OpenMP
# ==============================================================================
THREAD_SWEEP = (1, 2, 4, 8)

from numba.extending import intrinsic
from numba.core import types as nb_types
from llvmlite import ir as llvm_ir


@intrinsic
def compiler_barrier(typingctx):
    """Empty `asm volatile("" ::: "memory")`. Emits no machine instruction, but forbids
    LLVM from register-promoting the shared-array store and sinking it out of the loop
    (verified in the IR: without it the store is moved to the loop exit and the
    false-sharing effect disappears). The memory store really happens every iteration."""
    sig = nb_types.void()

    def codegen(context, builder, signature, args):
        asm = llvm_ir.InlineAsm(llvm_ir.FunctionType(llvm_ir.VoidType(), []), "", "~{memory}",
                                side_effect=True)
        builder.call(asm, [])
        return context.get_dummy_value()
    return sig, codegen


@njit(parallel=True)
def unpadded_state_omp(iters, seed_val):
    n_threads = get_num_threads()
    state = np.zeros(n_threads, dtype=np.int64)
    for t in prange(n_threads):
        tid = get_thread_id()
        x = np.int64(seed_val + tid * 1315423911)
        for step in range(iters):
            x = (x * np.int64(6364136223846793005) + np.int64(1442695040888963407)) \
                & np.int64(0x7FFFFFFFFFFFFFFF)
            state[tid] ^= (x >> 17)   # every worker hits the SAME 64-byte cache line
            compiler_barrier()        # keep the store inside the loop
    return state


@njit(parallel=True)
def padded_state_omp(iters, seed_val, pad_stride):
    n_threads = get_num_threads()
    # Each worker's active slot padded_state[tid, 0] is pad_stride * 8 bytes away
    # from its neighbour's slot -> it lives on its own cache line.
    padded_state = np.zeros((n_threads, pad_stride), dtype=np.int64)
    for t in prange(n_threads):
        tid = get_thread_id()
        x = np.int64(seed_val + tid * 1315423911)
        for step in range(iters):
            x = (x * np.int64(6364136223846793005) + np.int64(1442695040888963407)) \
                & np.int64(0x7FFFFFFFFFFFFFFF)
            padded_state[tid, 0] ^= (x >> 17)   # store stays INSIDE the loop
            compiler_barrier()
    return padded_state


print(f"\n[Task 2] False sharing benchmark  (ITERS_T2={ITERS_T2}, PAD_STRIDE={PAD_STRIDE} "
      f"-> {PAD_STRIDE * 8} B between worker slots)")
unpadded_state_omp(1000, STUDENT_ID)               # warm-up / JIT
padded_state_omp(1000, STUDENT_ID, PAD_STRIDE)     # warm-up / JIT

t2_unpadded_ms = {}
t2_padded_ms = {}
T2_REPEATS = 3   # best-of-3 to suppress turbo / P-core vs E-core scheduling noise
for nt in THREAD_SWEEP:
    set_num_threads(nt)
    best_un = best_pad = float("inf")
    for _rep in range(T2_REPEATS):
        t0 = time.perf_counter()
        s_un = unpadded_state_omp(ITERS_T2, STUDENT_ID)
        best_un = min(best_un, (time.perf_counter() - t0) * 1e3)
        t0 = time.perf_counter()
        s_pad = padded_state_omp(ITERS_T2, STUDENT_ID, PAD_STRIDE)
        best_pad = min(best_pad, (time.perf_counter() - t0) * 1e3)
        assert np.array_equal(s_un, s_pad[:, 0]), f"padded/unpadded state mismatch at {nt} threads"
    t2_unpadded_ms[nt] = best_un
    t2_padded_ms[nt] = best_pad
    print(f"  threads={nt}: unpadded={best_un:9.2f} ms   padded={best_pad:9.2f} ms   "
          f"ratio={best_un / best_pad:5.2f}x   states equal: OK   (best of {T2_REPEATS})")

T2_SPEEDUP_8 = t2_unpadded_ms[8] / t2_padded_ms[8]
print(f"  False-sharing penalty removed by padding @ 8 threads: {T2_SPEEDUP_8:.2f}x")
state_t2 = s_pad[:, 0].copy()   # 8-thread result, used by the final digest

DIAGNOSIS_T2 = (
    "In unpadded_state_omp the eight int64 slots state[0..7] occupy 64 contiguous bytes, i.e. one "
    "cache line, so all workers write to the same line on every iteration even though no two threads "
    "touch the same element. Under MESI a core must own a line in the Modified or Exclusive state "
    "before writing, so each writer issues a Read-For-Ownership that invalidates the other cores' "
    "copies (M -> I), and the line keeps bouncing between private L1/L2 caches. In padded_state_omp "
    f"each active slot is {PAD_STRIDE} int64 values ({PAD_STRIDE * 8} bytes) from the next, so every "
    "slot sits on its own line that stays Modified in its owner's L1 with no coherence traffic. "
    f"Measured (best of {T2_REPEATS}): 1 thread {t2_unpadded_ms[1]:.1f} vs {t2_padded_ms[1]:.1f} ms, "
    f"8 threads {t2_unpadded_ms[8]:.1f} vs {t2_padded_ms[8]:.1f} ms, a padded speedup of "
    f"{T2_SPEEDUP_8:.2f}x at 8 threads. The penalty is smaller than the textbook picture because "
    "the loop's critical path is the PRNG dependency chain, not memory: each core retires its stores "
    "into the store buffer and forwards the value to its own next load, so the line ping-pong only "
    "slows the background drain of that buffer, and an owning core can commit several pending stores "
    "per transfer. On the hybrid i9-13900HX, P-core/E-core placement and turbo frequency drops add "
    "run-to-run noise of the same order. Padding is still the correct engineering choice: the states "
    "are bit-identical and the coherence traffic between workers is eliminated."
)


# ==============================================================================
# TASK 3: Irregular Workload Skew & Balanced Chunk Scheduler
# ==============================================================================
CHUNK_T3 = 16
rows_idx = np.arange(ROWS_T3, dtype=np.int64)
work_units_t3 = (40 + ((rows_idx * 7919 + STUDENT_ID) % SKEW_MOD) ** 2).astype(np.int64)


@intrinsic
def _opaque_f64(typingctx, x):
    """Returns x unchanged through an empty inline-asm register move. LLVM cannot see
    that the value is the same, so it does not fuse sin(x) and cos(x) into a single
    `sincos` call (that symbol is missing from some Windows/MSYS2 C runtimes and
    crashes with 'LLVM ERROR: Symbol not found: sincos'). The math is unchanged."""
    sig = nb_types.float64(nb_types.float64)

    def codegen(context, builder, signature, args):
        fnty = llvm_ir.FunctionType(llvm_ir.DoubleType(), [llvm_ir.DoubleType()])
        asm = llvm_ir.InlineAsm(fnty, "", "=x,0", side_effect=False)
        return builder.call(asm, [args[0]])
    return sig, codegen


@njit(inline="always")
def _row_score(r, units):
    acc = 0.0
    x = r * 1.0e-3
    for k in range(units):
        acc += math.sin(x) * math.cos(_opaque_f64(x)) + math.sqrt(abs(x) + 1.0)
        x += 1.0e-4
    return acc


@njit(parallel=True)
def static_skew_omp(work_units):
    n_rows = work_units.shape[0]
    n_threads = get_num_threads()
    out = np.zeros(n_rows, dtype=np.float64)
    ops = np.zeros((n_threads, 8), dtype=np.int64)     # padded per-thread op counters
    for r in prange(n_rows):                           # default static contiguous blocks
        tid = get_thread_id()
        out[r] = _row_score(r, work_units[r])
        ops[tid, 0] += work_units[r]
    return out, ops[:, 0].copy()


def build_balanced_schedule(work_units, n_threads, chunk):
    """Cost-aware chunk scheduler (LPT): split rows into chunks of `chunk` rows,
    sort chunks by cost (heaviest first) and always give the next chunk to the
    least-loaded worker. Returns a CSR-style row list per worker."""
    n_rows = work_units.shape[0]
    n_chunks = (n_rows + chunk - 1) // chunk
    starts = np.arange(n_chunks) * chunk
    costs = np.add.reduceat(work_units, starts)
    order = np.argsort(-costs, kind="stable")
    load = np.zeros(n_threads, dtype=np.int64)
    owner = np.empty(n_chunks, dtype=np.int64)
    for c in order:
        w = int(np.argmin(load))
        owner[c] = w
        load[w] += costs[c]
    rows_per_worker = [[] for _ in range(n_threads)]
    for c in range(n_chunks):
        s = c * chunk
        rows_per_worker[owner[c]].extend(range(s, min(n_rows, s + chunk)))
    ptr = np.zeros(n_threads + 1, dtype=np.int64)
    for w in range(n_threads):
        ptr[w + 1] = ptr[w] + len(rows_per_worker[w])
    rows = np.array([r for lst in rows_per_worker for r in lst], dtype=np.int64)
    return ptr, rows


@njit(parallel=True)
def balanced_skew_omp(work_units, ptr, rows):
    n_rows = work_units.shape[0]
    n_threads = get_num_threads()
    out = np.zeros(n_rows, dtype=np.float64)
    ops = np.zeros((n_threads, 8), dtype=np.int64)
    for w in prange(n_threads):                         # one worker list per OpenMP thread
        tid = get_thread_id()
        for j in range(ptr[w], ptr[w + 1]):
            r = rows[j]
            out[r] = _row_score(r, work_units[r])
            ops[tid, 0] += work_units[r]
    return out, ops[:, 0].copy()


def imbalance_ratio(ops):
    active = ops[ops > 0]
    return float(active.max() / active.min())


print(f"\n[Task 3] Skewed workload  (ROWS_T3={ROWS_T3}, SKEW_MOD={SKEW_MOD}, "
      f"total ops={int(work_units_t3.sum())})")
set_num_threads(1)
static_skew_omp(work_units_t3[:64])                              # warm-up / JIT
p0, r0 = build_balanced_schedule(work_units_t3[:64], 1, CHUNK_T3)
balanced_skew_omp(work_units_t3[:64], p0, r0)                    # warm-up / JIT

t3_static_ms, t3_bal_ms, t3_static_lir, t3_bal_lir = {}, {}, {}, {}
for nt in THREAD_SWEEP:
    set_num_threads(nt)
    t0 = time.perf_counter()
    out_static, ops_static = static_skew_omp(work_units_t3)
    t_s = (time.perf_counter() - t0) * 1e3
    t0 = time.perf_counter()
    ptr_t3, rows_t3 = build_balanced_schedule(work_units_t3, nt, CHUNK_T3)
    out_bal, ops_bal = balanced_skew_omp(work_units_t3, ptr_t3, rows_t3)
    t_b = (time.perf_counter() - t0) * 1e3
    diff = float(np.max(np.abs(out_static - out_bal)))
    assert diff < 1e-11, f"static/balanced mismatch {diff} at {nt} threads"
    assert int(ops_static.sum()) == int(work_units_t3.sum()) == int(ops_bal.sum())
    t3_static_ms[nt], t3_bal_ms[nt] = t_s, t_b
    t3_static_lir[nt], t3_bal_lir[nt] = imbalance_ratio(ops_static), imbalance_ratio(ops_bal)
    print(f"  threads={nt}: static={t_s:8.2f} ms (LIR {t3_static_lir[nt]:.4f})   "
          f"balanced={t_b:8.2f} ms (LIR {t3_bal_lir[nt]:.4f})   max|diff|={diff:.1e}")

assert t3_bal_lir[8] < 1.15, f"balanced LIR {t3_bal_lir[8]:.4f} must be < 1.15 at 8 threads"
print(f"  @8 threads: static LIR={t3_static_lir[8]:.4f}  balanced LIR={t3_bal_lir[8]:.4f} (< 1.15 OK)")
out_t3 = out_bal

DIAGNOSIS_T3 = (
    "Numba's default prange splits the rows into one contiguous block per thread, so every thread "
    "gets the same number of rows but not necessarily the same amount of work, because the cost of "
    "a row grows with the square of its skew factor. The parallel loop ends with an implicit "
    "barrier, so the region lasts as long as the most loaded thread (the straggler) while the others "
    "sit idle. Numba's CPU backend has no atomic fetch-and-add for a shared chunk cursor, so I use a "
    f"cost-aware chunk scheduler instead: the rows are cut into chunks of {CHUNK_T3}, the cost of each "
    "chunk is known in advance from work_units, the chunks are sorted from heaviest to lightest and "
    "each one is given to the currently least-loaded worker (Longest-Processing-Time greedy rule); "
    "each OpenMP thread then processes its own chunk list inside prange. Per-thread operation "
    "counters in padded rows measure the result: at 8 threads the load imbalance ratio was "
    f"{t3_static_lir[8]:.4f} for static blocks and {t3_bal_lir[8]:.4f} for the scheduler "
    f"({t3_static_ms[8]:.1f} ms vs {t3_bal_ms[8]:.1f} ms). For my STUDENT_ID the multiplier 7919 "
    "scatters heavy rows almost uniformly, so the static blocks already average out; the scheduler's "
    "advantage is that its bound (max load <= average + one chunk) holds for any cost distribution, "
    "including sorted or clustered heavy rows where static blocks would create a large straggler. "
    "Every row is computed by the same sequential code, so both outputs are identical."
)


# ==============================================================================
# TASK 4: Parallel Red-Black SOR Wavefront PDE Solver
# ==============================================================================
SOR_SWEEPS = 600


def make_grid_t4():
    U = np.zeros((GRID_H, GRID_W), dtype=np.float64)
    U[0, :] = 100.0
    U[-1, :] = -50.0
    U[:, 0] = 25.0 * np.sin(np.linspace(0, np.pi, GRID_H))
    U[:, -1] = 75.0 * np.cos(np.linspace(0, np.pi / 2, GRID_H))
    return U


@njit(parallel=True)
def sor_red_black_step(U, omega):
    H, W = U.shape
    n_threads = get_num_threads()
    max_buf = np.zeros((n_threads, 8), dtype=np.float64)   # padded per-thread max |delta|

    # RED sweep: (r + c) % 2 == 0 -> all neighbours are BLACK and read-only
    for r in prange(1, H - 1):
        tid = get_thread_id()
        c0 = 1 if (r % 2 == 1) else 2
        for c in range(c0, W - 1, 2):
            old = U[r, c]
            new = (1.0 - omega) * old + 0.25 * omega * (
                U[r - 1, c] + U[r + 1, c] + U[r, c - 1] + U[r, c + 1])
            U[r, c] = new
            d = abs(new - old)
            if d > max_buf[tid, 0]:
                max_buf[tid, 0] = d
    # implicit OpenMP barrier here: all RED cells are final before BLACK starts

    # BLACK sweep: (r + c) % 2 == 1 -> uses the freshly updated RED neighbours
    for r in prange(1, H - 1):
        tid = get_thread_id()
        c0 = 2 if (r % 2 == 1) else 1
        for c in range(c0, W - 1, 2):
            old = U[r, c]
            new = (1.0 - omega) * old + 0.25 * omega * (
                U[r - 1, c] + U[r + 1, c] + U[r, c - 1] + U[r, c + 1])
            U[r, c] = new
            d = abs(new - old)
            if d > max_buf[tid, 0]:
                max_buf[tid, 0] = d

    m = 0.0
    for t in range(n_threads):
        if max_buf[t, 0] > m:
            m = max_buf[t, 0]
    return m


def solve_pde_omp(sweeps, omega):
    U = make_grid_t4()
    history = np.zeros(sweeps, dtype=np.float64)
    for k in range(sweeps):
        history[k] = sor_red_black_step(U, omega)
    return U, history


print(f"\n[Task 4] Red-Black SOR  (grid {GRID_H}x{GRID_W}, omega={float(OMEGA_SOR):.4f}, "
      f"{SOR_SWEEPS} sweeps)")
set_num_threads(1)
sor_red_black_step(make_grid_t4(), OMEGA_SOR)          # warm-up / JIT

t4_ms = {}
grids_t4 = {}
for nt in THREAD_SWEEP:
    set_num_threads(nt)
    t0 = time.perf_counter()
    U_nt, hist_nt = solve_pde_omp(SOR_SWEEPS, OMEGA_SOR)
    t4_ms[nt] = (time.perf_counter() - t0) * 1e3
    grids_t4[nt] = U_nt
    diff = float(np.max(np.abs(U_nt - grids_t4[1])))
    assert diff < 1e-9, f"SOR result differs from 1-thread run by {diff} at {nt} threads"
    print(f"  threads={nt}: time={t4_ms[nt]:9.2f} ms  speedup={t4_ms[1] / t4_ms[nt]:5.2f}x  "
          f"max_delta[0]={hist_nt[0]:.3e}  max_delta[last]={hist_nt[-1]:.3e}  "
          f"max_abs_diff_vs_1T={diff:.1e}")
grid_t4 = grids_t4[8]


# ==============================================================================
# FINAL SECTION: DETERMINISTIC VERIFICATION & TELEMETRY BUNDLE
# ==============================================================================
set_num_threads(8 if (os.cpu_count() or 1) >= 8 else os.cpu_count())

for idx, diag in enumerate([DIAGNOSIS_T1, DIAGNOSIS_T2, DIAGNOSIS_T3], start=1):
    assert isinstance(diag, str) and len(diag.strip()) >= 80, f"Complete DIAGNOSIS_T{idx}!"

checksum_blob = (
    f"{STUDENT_ID}|"
    f"{int(np.sum(hist_t1))}|{float(np.sum(wsums_t1)):.4f}|"
    f"{int(np.bitwise_xor.reduce(state_t2))}|"
    f"{float(np.sum(out_t3)):.6f}|"
    f"{float(np.sum(grid_t4)):.6f}"
)
lab_digest = hashlib.sha256(checksum_blob.encode()).hexdigest()[:20].upper()

bundle = {
    "instructor": "Instructor - Sufyan bin Uzayr",
    "student_name": STUDENT_NAME,
    "student_id": STUDENT_ID,
    "omp_layer": nb.threading_layer(),
    "cpu_cores": os.cpu_count(),
    "verification_digest": lab_digest,
}
print("\n=== OPENMP PYTHON LAB VERIFICATION BUNDLE ===")
print(json.dumps(bundle, indent=2))